/*
 * main.cpp
 *
 *  Created on: Jan 30, 2017
 *      Author: eshinig
 */

#include "gtest/gtest.h"


int main(int argc, char* argv[])

{
    ::testing::InitGoogleTest(&argc,argv);
    return RUN_ALL_TESTS();
}
